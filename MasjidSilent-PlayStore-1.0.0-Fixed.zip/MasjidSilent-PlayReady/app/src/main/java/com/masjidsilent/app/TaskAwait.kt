package com.masjidsilent.app

import com.google.android.gms.tasks.Task
import com.google.android.gms.location.Location
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

suspend fun Task<Location?>.awaitCompat(): Location? = suspendCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}
