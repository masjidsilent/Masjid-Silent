package com.masjidsilent.app

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

object LocationHelper {
    private const val REQUEST_CODE = 1001

    fun register(c: Context, masjids: List<Masjid>) {
        val fine = ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return

        val selected = masjids.take(100)
        Prefs.saveMasjids(c, selected)
        val client = LocationServices.getGeofencingClient(c)
        val pi = PendingIntent.getBroadcast(
            c, REQUEST_CODE, Intent(c, GeofenceReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        client.removeGeofences(pi).addOnCompleteListener {
            if (selected.isEmpty()) return@addOnCompleteListener
            val geofences = selected.map { m ->
                Geofence.Builder()
                    .setRequestId(m.id)
                    .setCircularRegion(m.lat, m.lon, m.radius)
                    .setExpirationDuration(Geofence.NEVER_EXPIRE)
                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT or Geofence.GEOFENCE_TRANSITION_DWELL)
                    .setLoiteringDelay(45_000)
                    .build()
            }
            val request = GeofencingRequest.Builder()
                .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
                .addGeofences(geofences)
                .build()
            client.addGeofences(request, pi)
        }
    }

    fun restoreSaved(c: Context) = register(c, Prefs.loadMasjids(c))
}
