# Masjid Silent 1.0.0

Masjid Silent is an Android app concept for automatically switching the phone to Do Not Disturb while the user is inside a mosque geofence, then restoring the previous interruption setting after leaving.

## Included
- Android 16 / API 36 target
- GPS / fused-location support
- OpenStreetMap map rendering with osmdroid
- OpenStreetMap/Overpass mosque discovery
- Up to 100 active geofences
- Automatic ENTER / DWELL / EXIT handling
- Previous DND interruption filter restoration
- Re-registration after device boot
- English-only production UI
- Play Store listing, privacy-policy, and release checklist templates

## Important limitation
This is a **source project**, not a signed Google Play App Bundle. A Play Store release must be built and signed with the developer's own upload key, and the Play Console declarations must be completed by the publisher.

## Build requirements
- Android Studio with Android SDK 36
- JDK 17
- Gradle 8.13 with Android Gradle Plugin 8.13.x

Open the project folder in Android Studio, allow Gradle to sync, then use **Build > Generate Signed Bundle / APK > Android App Bundle** for the Play Store release.

## Permissions
The app needs precise location, background location for geofencing, and Notification Policy Access for DND control. Notification permission is used for user-facing status notifications on Android 13+.

Background location should only be requested when the user enables the automatic mosque-detection feature. Complete Google's background-location disclosure and Play Console declaration requirements before publishing.

## Data source
Mosque discovery uses OpenStreetMap/Overpass. It does not guarantee that every mosque worldwide is mapped.

## Package name
`com.masjidsilent.app`

Change the package/application ID before publishing if you want a different unique ID.
