# Google Play release checklist

1. Open the project in Android Studio.
2. Install Android SDK 36 and use JDK 17.
3. Sync Gradle and resolve all dependencies.
4. Test location permission, background geofencing, DND access, ENTER/DWELL/EXIT, reboot restoration, and battery behavior on real devices.
5. Create your own upload/release keystore.
6. Build a signed Android App Bundle (.aab).
7. Create the Play Console app and complete App content, Data safety, privacy policy, content rating, and target audience declarations.
8. Provide a public privacy-policy URL.
9. Upload the six 9:16 screenshots and app icon/store graphics.
10. Start with internal testing, then closed testing, then production when eligible.

The app targets API 36 to meet the current Google Play target API requirement for new apps and updates from 31 August 2026.
