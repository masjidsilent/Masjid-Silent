# Masjid Silent — Play Store listing draft

## App name
Masjid Silent

## Short description
Automatically silence your phone near a mosque.

## Full description
Masjid Silent helps you keep your phone respectful around mosques.

Enable automatic mosque detection and the app can switch your phone to Do Not Disturb when you enter a supported mosque area. When you leave, it restores the interruption setting that was active before the visit.

### Features
- Discover nearby mosques from OpenStreetMap data
- View mosque locations on a map
- Automatic mosque-area geofencing
- Do Not Disturb activation on entry
- Restore the previous interruption setting on exit
- Background operation for automatic detection
- Re-register saved mosque areas after device restart
- Adjustable detection radius in the project configuration

Mosque data depends on OpenStreetMap coverage and may be incomplete or outdated in some locations.

Masjid Silent is designed to encourage a quieter, more respectful phone experience around places of worship.
