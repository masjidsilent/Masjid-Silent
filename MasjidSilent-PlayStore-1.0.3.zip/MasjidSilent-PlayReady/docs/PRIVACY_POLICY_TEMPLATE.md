# Privacy Policy — Masjid Silent

Replace the placeholders below with your legal entity/contact details before publishing.

**Effective date:** [DATE]

Masjid Silent uses device location to discover nearby mosque locations and to operate geofences for the automatic silent feature.

## Location data
Location is processed on the device to determine the user's position and to register mosque geofences. Mosque discovery requests may send approximate/current coordinates to the OpenStreetMap/Overpass service to retrieve nearby mapped places of worship.

## Notifications and Do Not Disturb
The app uses Android Notification Policy Access only to activate and restore the user's interruption-filter setting when entering or leaving a mosque geofence.

## Data storage
Saved mosque/geofence settings are stored locally on the device. The app does not require a user account.

## Third-party services
Map and mosque data are supplied by OpenStreetMap-related services. Review their current terms and privacy policies before publication.

## Contact
[LEGAL ENTITY]
[EMAIL]
[ADDRESS]
