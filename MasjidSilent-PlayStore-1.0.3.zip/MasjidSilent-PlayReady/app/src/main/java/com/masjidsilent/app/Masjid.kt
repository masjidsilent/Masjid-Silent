package com.masjidsilent.app

data class Masjid(
    val id: String,
    val name: String,
    val lat: Double,
    val lon: Double,
    val radius: Float = 120f
)
