package com.masjidsilent.app

import android.content.Context
import android.app.NotificationManager
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private const val P = "masjid_silent"
    private const val FILTER = "saved_filter"
    private const val ACTIVE_IDS = "active_ids"
    private const val MASJIDS = "masjids"

    private fun p(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    fun saveFilter(c: Context, filter: Int) = p(c).edit().putInt(FILTER, filter).apply()
    fun filter(c: Context): Int? = if (p(c).contains(FILTER)) p(c).getInt(FILTER, NotificationManager.INTERRUPTION_FILTER_ALL) else null
    fun clearFilter(c: Context) = p(c).edit().remove(FILTER).apply()

    fun activeIds(c: Context): MutableSet<String> = p(c).getStringSet(ACTIVE_IDS, emptySet())?.toMutableSet() ?: mutableSetOf()
    fun saveActiveIds(c: Context, ids: Set<String>) = p(c).edit().putStringSet(ACTIVE_IDS, ids).apply()

    fun saveMasjids(c: Context, list: List<Masjid>) {
        val arr = JSONArray()
        list.take(100).forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id); put("name", m.name); put("lat", m.lat); put("lon", m.lon); put("radius", m.radius)
            })
        }
        p(c).edit().putString(MASJIDS, arr.toString()).apply()
    }

    fun loadMasjids(c: Context): List<Masjid> = runCatching {
        val arr = JSONArray(p(c).getString(MASJIDS, "[]"))
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(Masjid(o.getString("id"), o.getString("name"), o.getDouble("lat"), o.getDouble("lon"), o.optDouble("radius", 120.0).toFloat()))
            }
        }
    }.getOrDefault(emptyList())
}
