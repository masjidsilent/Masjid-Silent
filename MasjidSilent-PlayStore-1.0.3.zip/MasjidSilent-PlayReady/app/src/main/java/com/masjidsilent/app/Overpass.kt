package com.masjidsilent.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object Overpass {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun nearby(lat: Double, lon: Double, radius: Int = 7000): List<Masjid> = withContext(Dispatchers.IO) {
        val q = "[out:json][timeout:30];(nwr[amenity=place_of_worship][religion=muslim](around:$radius,$lat,$lon);nwr[building=mosque](around:$radius,$lat,$lon););out center tags;"
        val url = "https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(q, "UTF-8")
        val request = Request.Builder().url(url).header("User-Agent", "MasjidSilent/1.0 (Android)").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Overpass HTTP ${response.code}")
            val body = response.body?.string().orEmpty()
            val arr = JSONObject(body).getJSONArray("elements")
            val out = mutableListOf<Masjid>()
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val tags = e.optJSONObject("tags") ?: JSONObject()
                val center = e.optJSONObject("center")
                val la = if (e.has("lat")) e.optDouble("lat") else center?.optDouble("lat", Double.NaN) ?: Double.NaN
                val lo = if (e.has("lon")) e.optDouble("lon") else center?.optDouble("lon", Double.NaN) ?: Double.NaN
                if (la.isNaN() || lo.isNaN()) continue
                val name = tags.optString("name").ifBlank { tags.optString("name:en").ifBlank { "Mosque" } }
                val type = e.optString("type", "element")
                val id = "$type:${e.optLong("id", i.toLong())}"
                out += Masjid(id, name, la, lo)
            }
            out.distinctBy { it.id }.sortedBy { distanceKm(lat, lon, it.lat, it.lon) }
        }
    }

    private fun distanceKm(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(bLat - aLat)
        val dLon = Math.toRadians(bLon - aLon)
        val x = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(aLat)) * Math.cos(Math.toRadians(bLat)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
        return r * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x))
    }
}
