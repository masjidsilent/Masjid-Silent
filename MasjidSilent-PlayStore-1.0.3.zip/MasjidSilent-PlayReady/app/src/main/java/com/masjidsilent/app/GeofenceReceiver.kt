package com.masjidsilent.app

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val ids = event.triggeringGeofences?.map { it.requestId }?.toSet().orEmpty()
        when (event.geofenceTransition) {
            Geofence.GEOFENCE_TRANSITION_ENTER, Geofence.GEOFENCE_TRANSITION_DWELL -> enter(context, nm, ids)
            Geofence.GEOFENCE_TRANSITION_EXIT -> exit(context, nm, ids)
        }
    }

    private fun enter(c: Context, nm: NotificationManager, ids: Set<String>) {
        if (!nm.isNotificationPolicyAccessGranted || ids.isEmpty()) return
        val active = Prefs.activeIds(c)
        if (active.isEmpty()) Prefs.saveFilter(c, nm.currentInterruptionFilter)
        active.addAll(ids)
        Prefs.saveActiveIds(c, active)
        runCatching { nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE) }
    }

    private fun exit(c: Context, nm: NotificationManager, ids: Set<String>) {
        if (ids.isEmpty()) return
        val active = Prefs.activeIds(c)
        active.removeAll(ids)
        Prefs.saveActiveIds(c, active)
        if (active.isEmpty() && nm.isNotificationPolicyAccessGranted) {
            Prefs.filter(c)?.let { runCatching { nm.setInterruptionFilter(it) } }
            Prefs.clearFilter(c)
        }
    }
}
