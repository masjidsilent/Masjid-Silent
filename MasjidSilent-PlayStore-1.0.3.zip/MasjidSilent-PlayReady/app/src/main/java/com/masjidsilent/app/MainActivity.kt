package com.masjidsilent.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {
    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = "MasjidSilent/1.0 (Android)"
        setContent { MasjidSilentApp() }
    }

    private fun hasFineLocation() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    private fun hasBackgroundLocation() = Build.VERSION.SDK_INT < 29 ||
        ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_BACKGROUND_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

    private fun requestLocation() {
        locationPermission.launch(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        )
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
        })
    }

    private fun openDndSettings() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @SuppressLint("MissingPermission")
    @Composable
    private fun MasjidSilentApp() {
        val scope = rememberCoroutineScope()
        var masjids by remember { mutableStateOf(Prefs.loadMasjids(this)) }
        var status by remember { mutableStateOf("Ready. Enable Location and Do Not Disturb access to begin.") }
        var busy by remember { mutableStateOf(false) }

        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = androidx.compose.ui.graphics.Color(0xFF087F5B),
                secondary = androidx.compose.ui.graphics.Color(0xFF2E8B72)
            )
        ) {
            Scaffold(
                topBar = { TopAppBar(title = { Text("Masjid Silent") }) }
            ) { padding ->
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            "Automatically silence your phone when you enter a mosque area.",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { requestLocation() }) { Text("Location") }
                            OutlinedButton(onClick = { openDndSettings() }) { Text("Silent access") }
                        }
                    }
                    if (!hasBackgroundLocation()) {
                        item {
                            OutlinedButton(onClick = { openAppSettings() }) {
                                Text("Allow background location")
                            }
                        }
                    }
                    item {
                        Button(
                            enabled = !busy,
                            onClick = {
                                if (!hasFineLocation()) {
                                    status = "Please allow precise location first."
                                    requestLocation()
                                    return@Button
                                }
                                if (Build.VERSION.SDK_INT >= 33 &&
                                    ContextCompat.checkSelfPermission(
                                        this@MainActivity, Manifest.permission.POST_NOTIFICATIONS
                                    ) != PackageManager.PERMISSION_GRANTED
                                ) {
                                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                scope.launch {
                                    busy = true
                                    status = "Finding nearby mosques…"
                                    runCatching {
                                        val location = LocationServices
                                            .getFusedLocationProviderClient(this@MainActivity)
                                            .lastLocation.awaitCompat()
                                        requireNotNull(location) {
                                            "GPS location is unavailable. Turn Location on and try again."
                                        }
                                        Overpass.nearby(location.latitude, location.longitude)
                                    }.onSuccess { found ->
                                        masjids = found.take(100)
                                        Prefs.saveMasjids(this@MainActivity, masjids)
                                        LocationHelper.register(this@MainActivity, masjids)
                                        status = "${masjids.size} mosque locations loaded. Automatic detection is ready."
                                    }.onFailure {
                                        status = it.message ?: "Could not load mosque locations."
                                    }
                                    busy = false
                                }
                            }
                        ) { Text(if (busy) "Searching…" else "Find nearby mosques") }
                    }
                    item { Text(status, style = MaterialTheme.typography.bodyMedium) }
                    item {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            AndroidView(
                                modifier = Modifier.fillMaxWidth().height(320.dp),
                                factory = { ctx ->
                                    MapView(ctx).apply {
                                        setMultiTouchControls(true)
                                        controller.setZoom(3.5)
                                        if (masjids.isNotEmpty()) {
                                            controller.setCenter(GeoPoint(masjids.first().lat, masjids.first().lon))
                                        }
                                    }
                                },
                                update = { map ->
                                    map.overlays.clear()
                                    masjids.forEach { mosque ->
                                        map.overlays.add(Marker(map).apply {
                                            position = GeoPoint(mosque.lat, mosque.lon)
                                            title = mosque.name
                                            snippet = "Silent radius: ${mosque.radius.toInt()} m"
                                        })
                                    }
                                    map.invalidate()
                                }
                            )
                        }
                    }
                    item {
                        Text("Detected mosques", style = MaterialTheme.typography.titleMedium)
                    }
                    items(masjids) { mosque ->
                        ListItem(
                            headlineContent = { Text(mosque.name) },
                            supportingContent = {
                                Text("${"%.5f".format(mosque.lat)}, ${"%.5f".format(mosque.lon)} • ${mosque.radius.toInt()} m")
                            }
                        )
                        HorizontalDivider()
                    }
                    item {
                        Text(
                            "Mosque data comes from OpenStreetMap contributors. Coverage varies by area.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
