# Masjid Silent release rules. Keep empty unless obfuscation is enabled.
